// 1. Estado central del carrito  
