// ===============================
// Go Life Premium - Carrito Unificado (versión robusta)
// ===============================

// --- Estado ---
let carrito = [];

// --- Funciones de almacenamiento ---
function saveCart() {
  localStorage.setItem("carrito", JSON.stringify(carrito));
}
function loadCart() {
  const data = localStorage.getItem("carrito");
  carrito = data ? JSON.parse(data) : [];
  renderCart();
}

// --- Helper: obtener refs seguras cada vez ---
function refs() {
  return {
    cartPanel: document.getElementById("cart-panel"),
    cartItems: document.getElementById("cart-items"),
    cartTotal: document.getElementById("cart-total"),
    cartCount: document.getElementById("cart-count"),
    floatingCartCount: document.getElementById("floating-cart-count"),
    floatingCartButton: document.getElementById("floating-cart-button"),
    closeCart: document.getElementById("close-cart"),
    clearCart: document.getElementById("clear-cart"),
    checkoutBtn: document.getElementById("checkout"),
    openCartBtn: document.getElementById("open-cart"),
    overlay: document.getElementById("cart-overlay"),
  };
}

// --- Render tolerante ---
function renderCart() {
  const r = refs();

  let total = 0;
  let totalQty = 0;
  carrito.forEach(p => {
    total += p.price * p.qty;
    totalQty += p.qty;
  });

  // Actualizar contadores visibles aunque falte el panel
  if (r.cartCount) r.cartCount.textContent = totalQty;
  if (r.floatingCartCount) r.floatingCartCount.textContent = totalQty;

  // Glow dorado si hay productos
  if (r.openCartBtn) {
    if (totalQty > 0) r.openCartBtn.classList.add("glow");
    else r.openCartBtn.classList.remove("glow");
  }

  // Si no hay panel/lista/total, solo persistimos y salimos
  if (!r.cartItems || !r.cartTotal) {
    saveCart();
    return;
  }

  // Render completo
  r.cartItems.innerHTML = "";
  carrito.forEach((p, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      ${p.product} x${p.qty} - $${(p.price * p.qty).toFixed(2)}
      <div class="controls">
        <button data-action="qty" data-index="${index}" data-delta="-1">−</button>
        <button data-action="qty" data-index="${index}" data-delta="1">+</button>
        <button data-action="remove" data-index="${index}">✖</button>
      </div>
    `;
    r.cartItems.appendChild(li);
  });

  r.cartTotal.textContent = total.toFixed(2);
  saveCart();
}

// --- Cambios de cantidad / eliminar ---
function changeQty(index, delta) {
  if (!carrito[index]) return;
  carrito[index].qty += delta;
  if (carrito[index].qty <= 0) carrito.splice(index, 1);
  renderCart();
}
function removeItem(index) {
  carrito.splice(index, 1);
  renderCart();
}

// --- Animación badge ---
function animateBadge() {
  const r = refs();
  if (r.openCartBtn) r.openCartBtn.classList.add("bump");
  if (r.floatingCartButton) r.floatingCartButton.classList.add("bump");
  setTimeout(() => {
    if (r.openCartBtn) r.openCartBtn.classList.remove("bump");
    if (r.floatingCartButton) r.floatingCartButton.classList.remove("bump");
  }, 300);
}

// --- Abrir/cerrar panel (ligado dinámicamente) ---
function openCartPanel() {
  const r = refs();
  if (r.cartPanel) r.cartPanel.classList.add("open");
  if (r.overlay) r.overlay.classList.add("active");
}
function closeCartPanel() {
  const r = refs();
  if (r.cartPanel) {
    r.cartPanel.classList.remove("open");
    r.cartPanel.classList.add("closing");
    r.cartPanel.addEventListener("animationend", () => {
      r.cartPanel.classList.remove("closing");
    }, { once: true });
  }
  if (r.overlay) r.overlay.classList.remove("active");
}

// --- Delegación global de eventos ---
document.addEventListener("click", (e) => {
  const r = refs();

  // Abrir desde header icon
  if (e.target.closest("#open-cart")) {
    openCartPanel();
    const btn = r.openCartBtn;
    if (btn) {
      btn.classList.add("shake");
      setTimeout(() => btn.classList.remove("shake"), 600);
    }
    return;
  }

  // Botón flotante
  if (e.target.closest("#floating-cart-button")) {
    openCartPanel();
    return;
  }

  // Cerrar por botón
  if (e.target.closest("#close-cart")) {
    closeCartPanel();
    return;
  }

  // Cerrar por overlay
  if (e.target.closest("#cart-overlay")) {
    closeCartPanel();
    return;
  }

  // Vaciar carrito
  if (e.target.closest("#clear-cart")) {
    carrito = [];
    renderCart();
    return;
  }

  // Checkout
  if (e.target.closest("#checkout")) {
    if (carrito.length === 0) {
      alert("Tu carrito está vacío.");
      return;
    }
    let mensaje = "Hola, le escribo de Go Life Premium. Quiero pedir:\n";
    carrito.forEach(p => (mensaje += `- ${p.product} x${p.qty}\n`));
    const r2 = refs();
    mensaje += `Total: $${r2.cartTotal ? r2.cartTotal.textContent : "0.00"}`;
    window.open(`https://wa.me/584224654331?text=${encodeURIComponent(mensaje)}`);
    return;
  }

  // Agregar al carrito
  const addBtn = e.target.closest(".add-to-cart");
  if (addBtn) {
    const product = addBtn.dataset.product;
    const price = parseFloat(addBtn.dataset.price);
    const card = addBtn.closest(".featured-card, .card, .row");
    const qtyInput = card ? card.querySelector(".qty") : null;
    const qty = qtyInput ? parseInt(qtyInput.value, 10) || 1 : 1;

    const item = carrito.find(p => p.product === product);
    if (item) item.qty += qty;
    else carrito.push({ product, price, qty });

    renderCart();
    animateBadge();
    openCartPanel();
    return;
  }

  // +/- en selector de cantidad
  const qtyBtn = e.target.closest(".qty-btn");
  if (qtyBtn) {
    e.preventDefault();
    const wrapper = qtyBtn.closest(".qty-selector");
    const input = wrapper ? wrapper.querySelector(".qty") : null;
    if (!input) return;
    const current = parseInt(input.value, 10) || 1;
    const min = parseInt(input.min, 10) || 1;
    const max = parseInt(input.max, 10) || 999;
    const isPlus = qtyBtn.classList.contains("plus");
    const isMinus = qtyBtn.classList.contains("minus");
    let next = current;
    if (isPlus) next = Math.min(current + 1, max);
    if (isMinus) next = Math.max(current - 1, min);
    input.value = next;
    return;
  }

  // Controles dentro del panel (qty/remove) por delegación
  const controlBtn = e.target.closest(".controls button");
  if (controlBtn) {
    const action = controlBtn.dataset.action;
    const index = parseInt(controlBtn.dataset.index, 10);
    if (action === "qty") {
      const delta = parseInt(controlBtn.dataset.delta, 10);
      changeQty(index, delta);
    } else if (action === "remove") {
      removeItem(index);
    }
  }
});

// --- Inicializar al cargar DOM ---
document.addEventListener("DOMContentLoaded", loadCart);