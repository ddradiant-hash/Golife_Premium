const slider   = document.querySelector('.testis-slider');
const prevBtn  = document.querySelector('.slide-btn.prev');
const nextBtn  = document.querySelector('.slide-btn.next');
const cards    = Array.from(document.querySelectorAll('.testis-slider .testi'));

/* Paso dinámico: ancho de una card + gap real del CSS */
function getStep() {
  const gap = parseInt(getComputedStyle(slider).gap) || 0;
  const cardWidth = cards[0]?.offsetWidth || 0;
  return cardWidth + gap;
}

/* Limites de scroll para decidir visibilidad */
function getBounds() {
  const max = slider.scrollWidth - slider.clientWidth;
  return { min: 0, max };
}

/* Ir a índice concreto, con límites */
let currentIndex = 0;
function goToIndex(index) {
  const step = getStep();
  const lastIndex = Math.max(0, cards.length - 1);
  currentIndex = Math.max(0, Math.min(index, lastIndex));
  slider.scrollTo({ left: currentIndex * step, behavior: 'smooth' });
  updateButtonsByScroll(); // sincroniza visibilidad
}

/* Avanzar/retroceder */
function nextSlide() { goToIndex(currentIndex + 1); }
function prevSlide() { goToIndex(currentIndex - 1); }

/* Oculta/muestra flechas según scroll real (más preciso que solo índice) */
function updateButtonsByScroll() {
  const { min, max } = getBounds();
  const left = slider.scrollLeft;

  // tolerancia para evitar parpadeos por subpíxeles
  const epsilon = 2;

  const atStart = left <= min + epsilon;
  const atEnd   = left >= max - epsilon;

  prevBtn.classList.toggle('is-hidden', atStart);
  nextBtn.classList.toggle('is-hidden', atEnd);
}

/* Eventos */
prevBtn.addEventListener('click', prevSlide);
nextBtn.addEventListener('click', nextSlide);

/* Sincroniza índice y visibilidad cuando hay drag/trackpad/táctil */
slider.addEventListener('scroll', () => {
  const step = getStep();
  const idx = Math.round(slider.scrollLeft / step);
  if (idx !== currentIndex) currentIndex = idx;
  updateButtonsByScroll();
});

/* Inicialización */
updateButtonsByScroll();