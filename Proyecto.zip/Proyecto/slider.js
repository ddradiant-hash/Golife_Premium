/* 1. ELEMENTOS */
const slider = document.querySelector('.testis-slider');
const prevBtn = document.querySelector('.slide-btn.prev');
const nextBtn = document.querySelector('.slide-btn.next');
const cards = Array.from(document.querySelectorAll('.testis-slider .testi'));

/* 2. MEDIDAS DINÁMICAS: ancho de card + gap real del CSS */
function getStep() {
  const gap = parseInt(getComputedStyle(slider).gap) || 0;
  const cardWidth = cards[0]?.offsetWidth || 0;
  return cardWidth + gap;
}

let currentIndex = 0;

/* 3. NAVEGACIÓN */
function goToSlide(index) {
  const step = getStep();
  currentIndex = Math.max(0, Math.min(index, cards.length - 1));
  slider.scrollTo({ left: currentIndex * step, behavior: 'smooth' });
}

function nextSlide() { goToSlide(currentIndex + 1); }
function prevSlide() { goToSlide(currentIndex - 1); }

/* 4. EVENTOS */
prevBtn.addEventListener('click', prevSlide);
nextBtn.addEventListener('click', nextSlide);

/* 5. SINCRONIZAR INDEX AL SCROLL (por si hay drag/trackpad) */
slider.addEventListener('scroll', () => {
  const step = getStep();
  const idx = Math.round(slider.scrollLeft / step);
  if (idx !== currentIndex) currentIndex = idx;
});